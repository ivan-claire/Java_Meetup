/**
 * Objects of this class are used to calculate the annual Carbon footprint
 * produced by a bicycle
 */
package test;

/**
 *
 * @author lehone_hope
 * The annual Carbon footprint produced by a bicycle is a function 
 * of the distance covered by the bicycle during the year and a standard Emission 
 * Factor EF
 */
public class Bicycle implements CarbonFootprint{
    private double distance;    //anual distance covered on bicycle
    private final double EF = 0.001;    //emmision factor for bicycle
    
    public Bicycle(){
        setDistance(0.0);
    }
    
    public Bicycle(double dist){
        setDistance(dist);
    }
    
    //set annual distance converd
    public void setDistance(double dist){
        if (dist >= 0.0)
            distance = dist;
        else
            throw new IllegalArgumentException(" Distance must >= 0.0km");
    }

    //get distance coverd
    public double getDistance(){
        return distance;
    }
    
    //override and implement the getCarbonFootprint method 
    @Override
    public double getCarbonFootprint(){
        return getDistance() * EF;   
    }
    
    @Override
    public String toString(){
        return String.format("Distance covered: ", getDistance());
    }
}//end class
