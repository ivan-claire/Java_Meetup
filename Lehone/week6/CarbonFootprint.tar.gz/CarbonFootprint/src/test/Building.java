/**
 * Objects of this class are used to calculate the annual Carbon footprint
 * produced from a building
 */
package test;

/**
 *
 * @author lehone_hope
 * Carbon footprints from building is a function of the sum of carbon footprints
 * from electricity usage(eUsage), natural gas usage(gasUsage) and cooking oil 
 * usage(oilUsage).
 * Each of these footprint is gotten as a function of their respective emission 
 * factor(EF)
 */
public class Building implements CarbonFootprint{
    private double eUsage;
    private double gasUsage;
    private double oilUsage;

    //emmission factors for all the various attribute
    private final double eEF = 0.6, gEF = 0.22, oEF = 3.1;
    
    //default constructor
    public Building(){
        setElectricalUsage(0.0);
        setGasUsage(0.0);
        setOilUsage(0.0);
    }//end default constructor
    
    //three argument constructor
    public Building(double eU, double gU, double oU){
        setElectricalUsage(eU);
        setGasUsage(gU);
        setOilUsage(oU);
    }//end five argument constructor
    
    //set the anual electrical usage
    public void setElectricalUsage(double eU){
        if (eU >= 0.0)
            eUsage = eU;
        else
            throw new IllegalArgumentException("Electricity used must be >= 0.0kWh");
    }//end set electricat usage
        
    //get anual electrical usage
    public double getElectricalUsage(){
        return eUsage;
    }//end get method
    
    //set the anual natural gas usage
    public void setGasUsage(double eU){
        if (eU >= 0.0)
            gasUsage = eU;
        else
            throw new IllegalArgumentException("Natural gas used must be >= 0.0l");
    }//end set Natural gas usage
        
    //get anual Natural gas usage
    public double getGasUsage(){
        return gasUsage;
    }//end get method
    
    //set the anual oil usage
    public void setOilUsage(double eU){
        if (eU >= 0.0)
            oilUsage = eU;
        else
            throw new IllegalArgumentException("Oil used must be >= 0.0l");
    }//end set oil usage
        
    //get anual oil usage
    public double getOilUsage(){
        return oilUsage;
    }//end get method
    
    //get emmission from electricity
    public double getElectricalFootprint(){
        return eEF * getElectricalUsage();
    }
    
    //get emmission from natural gas
    public double getGasFootprint(){
        return gEF * getGasUsage();
    }
    
    //get emmission from oil usage
    public double getOilFootprint(){
        return oEF * getOilUsage();
    }
    
    @Override
    public double getCarbonFootprint() {
        return getElectricalFootprint() + getGasFootprint() + getOilFootprint();
    }//end method getcarbonFootprint
    
    @Override
    public String toString(){
        return String.format("Footprint from Electricity: %.1fkgCo2/yr\n"
                + "Footprint from Natural gas: %.1fkgCo2/yr\n"
                + "Footprint from Oil: %.1fkgCo2/yr",
                getElectricalFootprint(), getGasFootprint(), getOilFootprint());
    }//end toString method
}//end main