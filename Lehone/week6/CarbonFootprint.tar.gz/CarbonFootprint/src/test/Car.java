/**
 * Objects of this class are used to calculate the annual Carbon footprint
 * produced from a Car
 */
package test;

/**
 *
 * @author lehone_hope
 * The annual carbon footprint of a car is a function of the distance traveled
 * during the year and it's emission factor.
 * With cars, there are two types of emissions: Direct and Indirect emission which
 * each have their emission factors: EFdir, EFind respectively
 */
public class Car implements CarbonFootprint{
    private double distance;
    private double EFdir = 0.186, EFind = 0.033;
    
    public Car(){
        setDistance(0.0);
    }//end default constructor
    
    public Car(double dist){
        setDistance(dist);
    }
    
    public void setDistance(double dist){
        if (dist >= 0.0)
            distance = dist;
        else
            throw new IllegalArgumentException(" Distance must >= 0.0km");
    }

    public double getDistance(){
        return distance;
    }
    
    public double getDirectFootprint(){
        return getDistance() * EFdir;
    }
    
    public double getIndirectFootprint(){
        return getDistance() * EFind;
    }
    
    @Override
    public double getCarbonFootprint() {
        return getDirectFootprint() + getIndirectFootprint();
    }
    
    @Override
    public String toString(){
        return String.format("Distance covered: %.1fkm", getDistance());
    }
}//end class Car