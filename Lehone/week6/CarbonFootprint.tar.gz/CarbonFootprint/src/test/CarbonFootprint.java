package test;

/**
 *
 * @author lehone_hope
 * Carbon Footprint interface provides getCarbonFootprint method which when 
 * implemented is suppose to return the carbon footprint of the object of the class
 * which implements it
 */
public interface CarbonFootprint {
        double getCarbonFootprint();
}//end interface
