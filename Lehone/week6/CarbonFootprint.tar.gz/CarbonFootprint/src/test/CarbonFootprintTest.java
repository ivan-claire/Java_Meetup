package test;

import java.util.ArrayList;

/**
 *
 * @author lehone_hope
 */
public class CarbonFootprintTest {
    public static void main(String[] args){
    
        //create objects of Bulding, Car and Bicycle classes
        Building myHouse = new Building(208, 67, 42);
        Car myCar = new Car(1500);
        Bicycle myBike = new Bicycle(53);
        
        ArrayList<CarbonFootprint> list = new ArrayList<>(); 
        list.add(myHouse);
        list.add(myCar);
        list.add(myBike);
        
        for(CarbonFootprint c : list){
            System.out.println(c.getClass().getName());
            System.out.printf("%s\nTotal Footprint: %.1fKgCO2/yr\n\n",
                    c.toString(), c.getCarbonFootprint());
        }
    }//end main
}//end main class
