/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exe9_3_bpce;

/**
 *
 * @author lehone_hope
 */
public class BPCETest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //create a BasePlusCommissionEmployee object bE
        BasePlusCommissionEmployee bE = new BasePlusCommissionEmployee("Lenya", 
            "Hope", "FE15A117", 50000, .04, 3000);
        
        System.out.println(bE.toString());
        
    }//end main
    
}//end class
