/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exe9_3_bpce;

/**
 *
 * @author lehone_hope
 */
public class BasePlusCommissionEmployee{
    
    //declare cE as a CommissionEmployee variable
    private CommissionEmployee cE;
    
    private double baseSalary; // base salary per week
    
    // six-argument constructor
    public BasePlusCommissionEmployee( String first, String last,
        String ssn, double sales, double rate, double salary ){
    
            //instantiate cE
            cE = new CommissionEmployee(first, last, ssn, sales, rate);
            setBaseSalary( salary ); // validate and store base salary
    } // end six-argument BasePlusCommissionEmployee constructor

    // set base salary
    public void setBaseSalary( double salary ){
        if ( salary >= 0.0 )
           baseSalary = salary;
    else
        throw new IllegalArgumentException(
            "Base salary must be >= 0.0" );
    } // end method setBaseSalary
    
    // return base salary
    public double getBaseSalary(){
        return baseSalary;
    } // end method getBaseSalary
    
    // calculate earnings
    public double earnings(){
        return getBaseSalary() + ( cE.getCommissionRate() * cE.getGrossSales() );
    } // end method earnings
    
    // return String representation of BasePlusCommissionEmployee
    @Override // indicates that this method overrides a superclass method
    public String toString(){
        return String.format("%s %s\n%s: %,.2fXFA", "base-salaried",
            cE.toString(), "base salary", getBaseSalary());
    }//end toString

}//end class